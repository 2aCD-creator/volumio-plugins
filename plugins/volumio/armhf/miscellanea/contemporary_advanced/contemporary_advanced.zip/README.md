## Contemporary Optimizations
With this plugin some optimizations for VOLUMIO UI are available

-----

##### Version: 1.01

* fix scale factor sample rate in mod 1
* optimize scaling for sample rate image

##### Version 1.0.0

* initial version