## Contemporary Optimizations
With this plugin some optimizations for VOLUMIO UI are available

-----
##### Version: 1.0.3

* compatibility with buster 3.152

##### Version: 1.0.2

* vertical center of recteangular albumarts

##### Version: 1.0.1

* fix scale factor sample rate in mod 1
* optimize scaling for sample rate image

##### Version 1.0.0

* initial version