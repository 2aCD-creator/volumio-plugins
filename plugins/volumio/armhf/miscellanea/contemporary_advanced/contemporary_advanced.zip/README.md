## Contemporary Optimizations
With this plugin some optimizations for VOLUMIO UI are available 
