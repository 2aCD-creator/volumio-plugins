## Contemporary Optimizations
With this plugin some optimizations for VOLUMIO UI are available

-----
##### Version: 1.0.6
* compatibility with buster 3.233

##### Version: 1.0.5

* fix little graphical issue on dedicated searchbar (mod 2)
* fix blur background if separate background picture for play view selected

##### Version: 1.0.4

* compatibility with buster 3.163
* add an option for blur background (only for buster)

##### Version: 1.0.3

* compatibility with buster 3.152

##### Version: 1.0.2

* vertical center of recteangular albumarts

##### Version: 1.0.1

* fix scale factor sample rate in mod 1
* optimize scaling for sample rate image

##### Version 1.0.0

* initial version