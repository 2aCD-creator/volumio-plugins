## PeppyScreensaver
PeppyMeter as screensaver for Volumio on raspberry pi
>Many thanks to peppy.player, who provided the conditions for this

 
